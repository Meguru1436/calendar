function login() {
    var email = document.getElementById("email").value;
    var heslo = document.getElementById("heslo").value;

    if (email == "admin" && heslo == "admin") {
        window.location.href = "cindex.html";
    }else {
        alert("Zadali jste špatné údaje.")
    }
}