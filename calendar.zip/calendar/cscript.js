function add() {
    var dateValue = document.getElementById("date").value;
    var timeValue = document.getElementById("time").value;
    var descriptionValue = document.getElementById("description").value;

    var newItem = document.createElement("li");
    newItem.innerHTML = `
        Dne : <span class="date">${dateValue}</span> v
        <span class="time">${timeValue}</span> hodin. Info o události:
        <span class="description">${descriptionValue}</span>
        <button class="btn" onclick="editItem(this)">Edit</button>
        <button class="btn" onclick="deleteItem(this)">Smazat</button>
    `;

    var list = document.getElementById("eventList");
    if (!list) {
        list = document.createElement("ul");
        list.id = "eventList";
        document.body.appendChild(list);
    }
    list.appendChild(newItem);

    document.getElementById("date").value = "";
    document.getElementById("time").value = "";
    document.getElementById("description").value = "";
}

function editItem(button) {
    var listItem = button.parentNode;

    var dateValue = listItem.querySelector('.date').textContent;
    var timeValue = listItem.querySelector('.time').textContent;
    var descriptionValue = listItem.querySelector('.description').textContent;

    var newDateValue = prompt("Enter the new date:", dateValue);
    var newTimeValue = prompt("Enter the new time:", timeValue);
    var newDescriptionValue = prompt("Enter the new description:", descriptionValue);

    if (newDateValue !== null && newTimeValue !== null && newDescriptionValue !== null) {
        listItem.querySelector('.date').textContent = newDateValue;
        listItem.querySelector('.time').textContent = newTimeValue;
        listItem.querySelector('.description').textContent = newDescriptionValue;
    }
}

function deleteItem(button) {
    var listItem = button.parentNode;
    listItem.parentNode.removeChild(listItem);
}
